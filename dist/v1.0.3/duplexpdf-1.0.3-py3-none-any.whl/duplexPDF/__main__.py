import duplexPDF

duplexPDF.Run()